import React from "react";
import Level4 from "./star/Level4";

const Menu = () => {
    return <Level4 />;
};

export default Menu;
