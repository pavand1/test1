import React from "react";
import Level2 from "./community/Level2";

const Community = () => {
    return <Level2 />;
};

export default Community;
