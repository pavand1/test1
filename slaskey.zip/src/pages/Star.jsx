import React from "react";
import Level3 from "./star/Level3";

const Star = () => {
    return <Level3 />;
};

export default Star;
