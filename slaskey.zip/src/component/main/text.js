export const text = `
**** The mountain path stretched ahead, treacherous and foreboding. Blindfolded, the man cautiously navigated the rugged terrain, his every step guided by the touch of a blind stick. Gravity’s relentless grasp claimed his leg, causing it to twist in agony. With a desperate twist of fate, the blind stick slipped from his grasp, vanishing into the unfathomable abyss below. Peril enveloped him, a profound realization of his precarious situation taking hold. In that moment, a gentle, mysterious breeze tenderly caressed his face, carrying with it a fragrant aroma that whispered of hope. Desperation coursed through his veins as he fumbled with the blindfold, his trembling hands striving to reclaim his sight. And then, as if awakening from a dark reverie, he found himself enveloped in the warm embrace of light.
“It had all been a mere dream,” he murmured, his voice a fragile whisper.
Moments passed, and he took deep breaths, slowly reclaiming his composure.

****
The following morning, he positioned himself outside, surrendering to the gentle caress of the sun’s warm rays. Golden light suffused the surroundings, casting a gentle glow upon the world. Each inhalation revitalized him, infusing his being with newfound energy and contentment, readying him to embrace the day’s challenges.

“Morning, Sals,” a voice`;
